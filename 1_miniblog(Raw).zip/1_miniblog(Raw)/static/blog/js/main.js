

// for home slider 
let slideIndex = 1;
      showSlides(slideIndex);
      
      function plusSlides(n) {
        showSlides(slideIndex += n);
      }
      
      function currentSlide(n) {
        showSlides(slideIndex = n);
      }
      
      function showSlides(n) {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");
        if (n > slides.length) {slideIndex = 1}    
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";  
        }
        for (i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";  
        dots[slideIndex-1].className += " active";
      }

      // slider End 



    // ///// ====load More Function===== //////


$(document).ready(function () {
      $(".loadmore").hide();
      $("#sec-3-btn").click(function () {
        $(".loadmore").toggle('slow')
        });
    });

    //  for Menu


// function openNav(){
//   document.getElementById("main_menu").style.width = "350px";
  
// }
// function closeNav(){
//   document.getElementById("main_menu").style.width = "85px";
  
// }


$(document).ready(function(){
  $(".contain").css({
    "margin-left" :"-100px"
  })
    $(".checkbtn").click(function(){
      $(".checkbtn").css({
        "display":"none",
      });
      $(".contain").css({
        "width" :"350px",
        "margin-left" :"0px"
      })
      
      $("")
    $("#close").click(function(){
      $(".checkbtn").css({
          "display":"flex",
      });
      $(".contain").css({
        "width":"85px",
        "margin-left" :"-100px"

      })

    });
  });
 
  
});
